"""
Celine is KING v.1.0.001
Programmer: Juan Thomas Alvarez
Copyrights Celine Dion, 2019.

General Information:
Program shows my favorite song. FYI It isn't really my favorite, I was just listening to it at the time.
"""

Song="The Hard Way" #Name of the song.
Duration=0.0023611111111111 #time where 24 hours = 1.
BPM=120 #Beats Per Minute (This value was made up).
Album="Courage (Deluxe Edition)" #The album the song was first released on.
YearReleased="2019" #Year the song was released.
Artist="Celine Dion" #The artist's recognized commercial name
Genre="World" #The main genre for artist, not the song.

#Print out each detail of favorite song on a new line
print(Song)
print(Duration)
print(BPM)
print(Album)
print(YearReleased)
print(Artist)
print(Genre)